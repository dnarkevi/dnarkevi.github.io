TooManyFootprints.GTP

This is a single stencil gerber with every package that we sell breakouts for as of june 2023. You can have it made by OSHStencils or many other low cost PCB stencil making companies.

Because it has all those packages on it, you can only paste up one board at a time. On the other hand, when you're working with a breakout board, that's probably what you'd be doing anyway. That is, this is just an easier way to solder one or more breakout boards, if you have a reflow oven/hotplate. Applying solder paste to the board like this will also help iron soledering, but notwhere near to the same extent.

Footprints included (all crammed onto one stencil), see map.png.

1. DFNn  0.65mm pitch No exposed pad, where n is less than 42
2. DFN8  0.65mm pitch 3mm x 3mm wide exposed pad.
3. DFN8  0.65mm pitch 3mm x 3mm wide exposed pad with extended pads and EP for hand soldering
4. DFN8  0.65mm pitch No Exposed Pad
5. DFN10 0.40mm pitch 0.6mm Exposed Pad 2mm x 2mm
6. DFN10 0.40mm pitch 1.25mm Exposed Pad 2.5mm x 2.5mm
7. DFN10 0.50mm pitch 1.3mm Exposed Pad 3mm x 3mm
8. DFN16 0.45mm pitch 1.6mm Exposed Pad
9. DFN16 0.50mm pitch 0.9mm Exposed Pad
10. DFN16 0.50mm pitch 1.1mm Exposed Pad
11. DFN16 0.50mm pitch No Exposed Pad
12. DFN16 0.65mm pitch 1.5mm Exposed Pad
13. DFN16 (Or MSOP) 0.50mm pitch 1.5mm Exposed Pad
14. DFN16 0.65mm pitch No Exposed Pad
15. uQFN8 1.5mm x 1.5mm 1-3-1-3 pins/side No Exposed Pad
16. uQFN10 0.40mm pitch 2-3-2-3 pins/side No Exposed Pad
17. uQFN10 0.50mm pitch 1-4-1-4 pins/side No Exposed Pad
18. USON10 - odd custom TI package
19. MINIQFN-16 0.40mm pitch, No Exposed Pad, a real bitch to solder.
20. MSOP or similer, no EP, up to 12 pins
21. QFN12 0.40mm pitch 2mm x 2mm
22. QFN12 0.50mm pitch 3mm x 3mm
23. QFN12 0.65mm pitch 4mm x 4mm
24. QFN12 0.80mm pitch 4mm x 4mm
25. QFN16 0.50mm pitch 3mm x 3mm
26. QFN16 0.65mm pitch 4mm x 4mm
27. DHVQFN16 0.40mm pitch, 2-6-2-6 pins/side Center pad often tied to Vdd instead of Gnd
28. DHX2QFN18 0.40mm pitch 2mm x 2.4mm  4-5-4-5 pins/side
29. QFN20 0.40mm pitch 3mm x 3mm
30. QFN20 0.45mm pitch 3mm x 3mm
31. QFN20 0.50mm pitch 4mm x 4mm
32. QFN20 0.65mm pitch 5mm x 5mm
33. QFN20 0.50mm pitch 5mm x 3.2mm (4-6-4-6 pins/side)
34. WQFN20 0.4mm pitch 3mm x 3mm No Exposed Pad, extended pads instead
35. QFN24 0.50mm pitch 4mm x 4mm
36. QFN24 0.65mm pitch 5mm x 5mm
37. QFN28 0.40mm pitch 4mm x 4mm
38. QFN28 0.45mm pitch 5mm x 5mm
39. QFN28 0.50mm pitch 5mm x 5mm
40. QFN28 0.65mm pitch 6mm x 6mm or 7mm x 7mm
41. QFN28 0.50mm pitch 5mm x 4mm (6-8-6-8 pins per side)
42. QFN32 0.40mm pitch 5mm x 5mm or 4mm x 4mm
43. QFN32 0.50mm pitch 5mm x 5mm or 6mm x 6mm
44. QFN32 0.65mm pitch 7mm x 7mm or 6mm x 6mm
45. QFN or QFP32 0.80mm pitch 9mm x 9mm Exposed Pad
46. QFN or QFP32 0.80mm pitch 9mm x 9mm No Exposed Pad
47. QFN48 0.40mm
48. SOIC24 - fits any wide or narrow SOIC (or SOP) pacakge
49. SOT23-6
50. SSOP28 - With EP
51. SSOP28 - No EP
52. XSON-8 extra large DFN similar in size to SOIC-8, usually uised for flash chips with very large die areas


For best results:
* Make sure that whatever you are using to hold the stencil in place (often acrylic angles) are no thicker than PCB, and preferably a hair thinner.
* Get the stencil made of stainless steel, not that yellow plastic (which I think is Kapton, only thicker and without the adhesive backing). This matters little for non-demanding packages, but is more significant as the going gets tougher.
* Do NOT use lead-free bismuth-rich solder paste on boards that do not have ENIG (gold) surface treatment. The HASL-treated breakouts (whichare on clearance, in part for this reason) are not lead-free HASL, it's leaded.
	* Do not mix leaded and bismuth-containing solderes in any way. There is a tiny spot right around the 96C-melting eutectic you really don't want any part of your solder to be within, and you really don't want the boundary between your tin-bismuth solder and leaded HASL boards havinga portion tht would melt at 95C.
* Use the right solder paste.
	* If niether legal nor ethical concerns preclude it, tin/lead solder (or even better, the stuffwith up to 2% silver - but this isn't a big deal - getting a decent brand matters more. Western brands you generally don't have to be concerned about the quality from, just the prices, which are often exorbitan. For leaded solder from cheap vendors in the East, KEK is very good, and relife isn't bad.
	* SAC305 is lead free, which is good, and tends tends to do quite well on fine pitch parts. Just, don't use SAC 305 lead free solder paste if your reflow oven does not get hot enough to reflow lead-free paste reliably. Test it with cheap crap parts first if you're not sure, and remember that the fact that the manufacturer said it could do lead free reflow doesn't mean it *actually* can. SAC305 of good quality can behad from almost any western brand, but for cheaper, yet good, SAC305,it's available from the East too.

	* Mijing 190A is used on many of our boards, because I've got the sort of reflow oven described above. It's a lead-free solder with the composition way over on the tin-heavy side, so-much-so that it adds a touch of copper to keep it from dissolving copper terminations (only available from Eastern suppliers).
	* Relife/Sunshine SP or SP-X - 158 C solder pastes, both claiming to be lead free. The SP most definitely is, and got and ambiguous result from t I think the only differences are in fluxes and particle size (the SP-X being the upmarket model). It blows away every other 158C lead free solder, and solidly beats the leaded ones. I have no idea what the magic alloy is! Only available from Eastern suppliers.
	* If using particularly temperature sensitive parts, 138C SnBi eutectic (available everywhere), or 137C SnBi eutectic + 1% Ag (only available from Western suppliers), but be warned that the alloy, particuarly without silver, is prone to brittle fracture, and has very disappointing thermal conductivity.
* Don't use what is known to be the wrong solder paste:
	* Anything made by Mechanic, particulaarly the stuff in the blue and orange jars, which is only T3, and leaded.
	* Anything sold under the Conduction or PPD brands (the PPD S600 lead free makes wonderful looking joints; it's a real shame it's not lead free (strong positive on lead tests). The other products those brands sell are simply of substandard quality.)
	* Anything advertising leaded 158C solder (it's 43:43:14 Sn:Pb:Bi, it's not very good solder, and it's still full of lead.
	* Any solder paste with approximately 65:35 Sn:Bi, typically with between 0.0 and 1.0% silver. Silver or non, this is horrible solder paste. Sold only from Eastern vendors, advertising Mp between 151C and 189C.
	* Anything where the claimed alloy and melting poing are inconsistent, especially where such errors are widespread and visible on the photos of the packaging.
	* 2UUL's 189C lead free (guess what? It's not lead free. They don't even say it is anywhere - it's just the sellers who try to hawk it as lead free). It also doesn't melt at 189C, it melts at more like 183C, as you would expect sice is is 63:37 tin-lead solderwith just a hint of silver in it. Anyway, it costs as much as, and comes out worse, than KEK's and Relife's. Their 148C solder is better than mechanics, but notice that you don't see 148C solder on the above list of the right solder pastes to use.
	* Chipquik's No Clean Water Washable. Chipquick seems to think they have made good water washable no-clean paste. They have not. It's got the same problem as no clean water washable flux they sell - the fluxing activity is poor, and the result disappointing - and the flux residue doesnot wash off with water, not even a little bit.
